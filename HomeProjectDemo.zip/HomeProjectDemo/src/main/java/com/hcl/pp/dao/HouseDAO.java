package com.hcl.pp.dao;

import java.util.List;

import com.hcl.pp.model.House;

public interface HouseDAO {
	public House getHouseById(long HOUSE_ID);

	public boolean saveHouse(House house);

	public List<House> fetchAll();
}
