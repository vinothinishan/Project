package com.hcl.pp.service;

import java.util.List;
import java.util.Set;

import com.hcl.pp.model.House;
import com.hcl.pp.model.User;

public interface HouseService {
	public House getHouseById(long HOUSE_ID);

	public boolean saveHouse(House house);

	public List<House> getAllHouses();
}
