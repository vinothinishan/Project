package com.hcl.pp.actions;

import java.util.NoSuchElementException;
import java.util.List;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pp.model.House;
import com.hcl.pp.model.User;
import com.hcl.pp.service.HouseService;
import com.hcl.pp.service.SecurityService;
import com.hcl.pp.service.UserService;

import jakarta.validation.Valid;

@Controller
@SessionAttributes("sessionuser")
public class HousesAppController {
	@Autowired
	private UserService userService;
	@Autowired
	private HouseService houseService;
	@Autowired
	private SecurityService securityService;
	private static Logger logger = (Logger) LogManager.getLogger(HousesAppController.class);

	@RequestMapping(value = "/user")
	public String welcome(Model model) {
		logger.info("Opened login page");
		model.addAttribute("user", new User());
		return "login";
	}

	@RequestMapping(value = "/user/add")
	public ModelAndView addUser(@Valid @ModelAttribute("user") User user, BindingResult bindingResult) {
		ModelAndView modelAndView = null;
		logger.info(user.getUserPassword() + " " + user.getConfirmPassword());
		if (bindingResult.getErrorCount() == 0 && user.getUserPassword().equals(user.getConfirmPassword())) {
			userService.addUser(user);
			modelAndView = new ModelAndView("registered");
		} else {
			logger.error(user.getUsername() + " " + user.getUserPassword() + " " + user.getConfirmPassword());
			modelAndView = new ModelAndView("userregn");
			modelAndView.addObject("nomatch", "Password and confirm password should be equal");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/user/new")
	public String newUser(@ModelAttribute("user") User user) {
		logger.info("New User Entry");
		return "userregn";
	}

	@RequestMapping(value = "/user/authenticate")
	public ModelAndView authenticateUser(@ModelAttribute("user") User user, Model model) {
		ModelAndView modelAndView = null;
		try {
			User sessionuser = securityService.authenticateUser(user);
			modelAndView = new ModelAndView("house_home");
			model.addAttribute("sessionuser", sessionuser);
		} catch (NoSuchElementException exception) {
			modelAndView = new ModelAndView("userregn");
			modelAndView.addObject("nouser", "No such user, Please register");
			logger.warn(user.getUsername() + " " + user.getUserPassword()
					+ " not in the database, redirecting to user registration page");
		}
		return modelAndView;
	};

	@RequestMapping(value = "/user/logout")
	public String logout(@ModelAttribute("sessionuser") User user) {
		logger.info(user.getUsername() + " logged out");
		return "login";
	}

	@RequestMapping(value = "/houses/myHouses")
	public String myHouses(@ModelAttribute("sessionuser") User user, Model model) {
		Set<House> houses = userService.getMyHouses(user);
		model.addAttribute("houses", houses);
		logger.info("my houses info");
		return "my_houses";
	}

	@RequestMapping(value = "/houses/houseDetail")
	public String houseDetail(Model model) {
		model.addAttribute("house", new House());
		logger.info("Adding houses");
		return "house_form";
	}

	@RequestMapping(value = "/houses/addHouse")
	public String addHouse(@ModelAttribute("house") House house) {
		houseService.saveHouse(house);
		logger.debug(house.getName() + " added");
		return "house_home";
	}

	@RequestMapping(value = "/houses/buyHouse", method = RequestMethod.GET)
	public String buyHouse(@ModelAttribute("sessionuser") User user, @RequestParam long houseId) {
		House house = houseService.getHouseById(houseId);
		userService.buyHouse(house, user);
		logger.debug(house.getName() + " bought by" + user.getUsername());
		return "house_home";
	}

	@RequestMapping(value = "/user/registered")
	public String registered(@ModelAttribute("user") User user) {
		logger.info(user.getUsername() + " registered");
		return "registered";
	}

	@RequestMapping(value = "/houses")
	public String houeHome(Model model) {
		List<House> houses = houseService.getAllHouses();
		model.addAttribute("houses", houses);
		logger.info("directing to house home page");
		return "house_home";
	}
}
