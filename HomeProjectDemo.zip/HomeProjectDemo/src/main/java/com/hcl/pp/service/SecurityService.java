package com.hcl.pp.service;

import com.hcl.pp.model.User;

public interface SecurityService {
	public User authenticateUser(User user) ;
}
